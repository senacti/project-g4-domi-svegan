# PAGINA WEB 2
*Responsive website**

> This is my first website after finishing university, to practice writing code and advance my knowledge of programming, and today i am learning Git

Using
- HTML
- CSS
- JAVASCRIPT
- GIT
:blue_heart:


