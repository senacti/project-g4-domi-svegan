### Proyecto-Dashboard.io

- Proyecto de Dashboard de cripto monedas;
- Llamado a API, usando javaScript /funciones async await/fetch/import y export;
- Creacion de chart.js usando HTML CSS y JAVASCRIPT;
- Se agragaron commit ;
- Conversion  de cripto monedas a dolar y a peso Mexicano;

[![2023-01-11-19h45-45.png](https://i.postimg.cc/fRWKcp4Y/2023-01-11-19h45-45.png)](https://postimg.cc/4mMVZ8x3)
