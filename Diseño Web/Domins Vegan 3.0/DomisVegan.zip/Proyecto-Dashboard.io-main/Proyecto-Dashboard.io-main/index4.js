import { createChart } from "./index.js";



createChart();